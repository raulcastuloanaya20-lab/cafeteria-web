function responder(o){
let r=document.getElementById("respuesta");
if(o==="menu")r.innerText="Tenemos café americano, latte, capuccino y pan dulce.";
else if(o==="horario")r.innerText="Abrimos de 8:00 am a 8:00 pm.";
else if(o==="ubicacion")r.innerText="Estamos en el centro de la ciudad.";
else if(o==="promos")r.innerText="Promoción 2x1 los viernes.";
}